"""
PumpRadar - FastAPI Backend
Crypto pump/dump signal analyzer with AI, LunarCrush & CoinGecko
"""
import os
import asyncio
import logging
import uuid
import requests
import hashlib
import secrets
import httpx
import stripe
import google.generativeai as genai
from datetime import datetime, timedelta, timezone
from typing import Optional, List, Dict, Any, Annotated

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Depends, status, Request, BackgroundTasks, Response, Cookie
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr, Field
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient
from passlib.context import CryptContext
from jose import JWTError, jwt
import resend

# ─────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────
MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]
JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")
JWT_EXPIRE_MINUTES = int(os.environ.get("JWT_EXPIRE_MINUTES", "10080"))
RESEND_API_KEY = os.environ["RESEND_API_KEY"]
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "onboarding@resend.dev")
LUNARCRUSH_API_KEY = os.environ["LUNARCRUSH_API_KEY"]
COINGECKO_API_KEY = os.environ.get("COINGECKO_API_KEY", "")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
STRIPE_API_KEY = os.environ["STRIPE_API_KEY"]
APP_URL = os.environ.get("APP_URL", "http://localhost:3000")
LOGO_URL = f"{APP_URL}/logo-pumpradar.png"

# Configure Gemini
genai.configure(api_key=GEMINI_API_KEY)

# Configure Stripe
stripe.api_key = STRIPE_API_KEY

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

resend.api_key = RESEND_API_KEY

# ─────────────────────────────────────────────
# App & DB
# ─────────────────────────────────────────────
app = FastAPI(title="PumpRadar API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer(auto_error=False)

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
def api_ok(data: Any) -> dict:
    return {"success": True, "data": data}

def api_err(msg: str, code: str = "ERROR") -> dict:
    return {"success": False, "error": {"code": code, "message": msg}}

def hash_password(p: str) -> str:
    return pwd_ctx.hash(p)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_ctx.verify(plain, hashed)

def create_token(user_id: str, email: str, expires_delta: Optional[timedelta] = None) -> str:
    exp = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=JWT_EXPIRE_MINUTES))
    return jwt.encode({"sub": user_id, "email": email, "exp": exp}, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])

def doc_to_user(doc: dict) -> dict:
    if not doc:
        return {}
    return {
        "id": str(doc["_id"]),
        "email": doc["email"],
        "name": doc.get("name", ""),
        "roles": doc.get("roles", ["viewer"]),
        "avatar": doc.get("avatar"),
        "emailVerified": doc.get("email_verified", False),
        "subscription": doc.get("subscription", "free"),
        "subscriptionExpiry": doc.get("subscription_expiry"),
        "createdAt": doc.get("created_at", "").isoformat() if isinstance(doc.get("created_at"), datetime) else doc.get("created_at", ""),
    }

async def get_current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> dict:
    if not creds:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = decode_token(creds.credentials)
        user_id = payload.get("sub")
        user = await db.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except (JWTError, Exception) as e:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_optional_user(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> Optional[dict]:
    if not creds:
        return None
    try:
        payload = decode_token(creds.credentials)
        user_id = payload.get("sub")
        return await db.users.find_one({"_id": ObjectId(user_id)})
    except Exception:
        return None

# ─────────────────────────────────────────────
# Email helpers
# ─────────────────────────────────────────────
async def send_verification_email(email: str, name: str, token: str):
    verify_url = f"{APP_URL}/auth/verify-email?token={token}"
    html = f"""
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#0f172a;border-radius:12px">
      <div style="text-align:center;margin-bottom:24px">
        <img src="{LOGO_URL}" alt="PumpRadar" style="width:64px;height:64px;border-radius:12px" />
        <h2 style="color:#fff;margin:16px 0 0 0">Welcome to PumpRadar!</h2>
      </div>
      <div style="background:#1e293b;padding:20px;border-radius:8px;color:#fff">
        <p style="margin:0 0 16px 0">Hi {name},</p>
        <p style="margin:0 0 20px 0;color:#94a3b8">Please verify your email address to activate your account and start receiving AI-powered crypto signals:</p>
        <div style="text-align:center">
          <a href="{verify_url}" style="background:linear-gradient(135deg,#10b981,#059669);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:bold">
            Verify Email Address
          </a>
        </div>
        <p style="color:#64748b;font-size:12px;margin:20px 0 0 0;text-align:center">This link expires in 24 hours.</p>
      </div>
    </div>"""
    try:
        await asyncio.to_thread(resend.Emails.send, {
            "from": f"PumpRadar <{SENDER_EMAIL}>",
            "to": [email],
            "subject": "Verify your email - PumpRadar",
            "html": html,
        })
    except Exception as e:
        logger.error(f"Email send error: {e}")

async def send_reset_email(email: str, token: str):
    reset_url = f"{APP_URL}/auth/reset-password?token={token}"
    html = f"""
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#0f172a;border-radius:12px">
      <div style="text-align:center;margin-bottom:24px">
        <img src="{LOGO_URL}" alt="PumpRadar" style="width:64px;height:64px;border-radius:12px" />
        <h2 style="color:#fff;margin:16px 0 0 0">Password Reset</h2>
      </div>
      <div style="background:#1e293b;padding:20px;border-radius:8px;color:#fff">
        <p style="margin:0 0 16px 0;color:#94a3b8">You requested a password reset. Click the button below:</p>
        <div style="text-align:center">
          <a href="{reset_url}" style="background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;display:inline-block;font-weight:bold">
            Reset Password
          </a>
        </div>
        <p style="color:#64748b;font-size:12px;margin:20px 0 0 0;text-align:center">This link expires in 1 hour. If you didn't request this, ignore this email.</p>
      </div>
    </div>"""
    try:
        await asyncio.to_thread(resend.Emails.send, {
            "from": f"PumpRadar <{SENDER_EMAIL}>",
            "to": [email],
            "subject": "Password Reset - PumpRadar",
            "html": html,
        })
    except Exception as e:
        logger.error(f"Reset email error: {e}")

# ─────────────────────────────────────────────
# AUTH MODELS
# ─────────────────────────────────────────────
class LoginDTO(BaseModel):
    email: EmailStr
    password: str
    remember: Optional[bool] = False

class RegisterDTO(BaseModel):
    email: EmailStr
    password: str
    name: str
    confirmPassword: Optional[str] = None

class ForgotPasswordDTO(BaseModel):
    email: EmailStr

class ResetPasswordDTO(BaseModel):
    token: str
    password: str
    confirmPassword: Optional[str] = None

class VerifyEmailDTO(BaseModel):
    token: str

# ─────────────────────────────────────────────
# AUTH ENDPOINTS
# ─────────────────────────────────────────────
@app.post("/api/auth/register")
async def register(dto: RegisterDTO):
    existing = await db.users.find_one({"email": dto.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail=api_err("Email already registered", "EMAIL_EXISTS"))
    
    verify_token = secrets.token_urlsafe(32)
    verify_expiry = datetime.now(timezone.utc) + timedelta(hours=24)
    
    # Free trial = 24h from registration
    trial_expiry = datetime.now(timezone.utc) + timedelta(hours=24)
    
    user_doc = {
        "email": dto.email.lower(),
        "name": dto.name,
        "password_hash": hash_password(dto.password),
        "roles": ["viewer"],
        "email_verified": False,
        "verify_token": verify_token,
        "verify_token_expiry": verify_expiry,
        "subscription": "trial",
        "subscription_expiry": trial_expiry,
        "created_at": datetime.now(timezone.utc),
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id
    
    access_token = create_token(str(result.inserted_id), dto.email)
    refresh_token = create_token(str(result.inserted_id), dto.email, timedelta(days=30))
    
    # Send verification email
    asyncio.create_task(send_verification_email(dto.email, dto.name, verify_token))
    
    return api_ok({
        "user": doc_to_user(user_doc),
        "accessToken": access_token,
        "refreshToken": refresh_token,
        "message": "Account created! Please check your email to verify.",
    })

@app.post("/api/auth/login")
async def login(dto: LoginDTO):
    user = await db.users.find_one({"email": dto.email.lower()})
    if not user or not verify_password(dto.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail=api_err("Incorrect email or password", "INVALID_CREDENTIALS"))
    
    # Email verification disabled - allow all logins
    expire = timedelta(days=30) if dto.remember else timedelta(minutes=JWT_EXPIRE_MINUTES)
    access_token = create_token(str(user["_id"]), user["email"], expire)
    refresh_token = create_token(str(user["_id"]), user["email"], timedelta(days=30))
    
    return api_ok({
        "user": doc_to_user(user),
        "accessToken": access_token,
        "refreshToken": refresh_token,
    })

@app.post("/api/auth/forgot-password")
async def forgot_password(dto: ForgotPasswordDTO):
    user = await db.users.find_one({"email": dto.email.lower()})
    if user:
        reset_token = secrets.token_urlsafe(32)
        reset_expiry = datetime.now(timezone.utc) + timedelta(hours=1)
        await db.users.update_one(
            {"_id": user["_id"]},
            {"$set": {"reset_token": reset_token, "reset_token_expiry": reset_expiry}}
        )
        asyncio.create_task(send_reset_email(dto.email, reset_token))
    
    return api_ok({"message": "If this email exists, you will receive reset instructions."})

@app.post("/api/auth/reset-password")
async def reset_password(dto: ResetPasswordDTO):
    user = await db.users.find_one({
        "reset_token": dto.token,
        "reset_token_expiry": {"$gt": datetime.now(timezone.utc)}
    })
    if not user:
        raise HTTPException(status_code=400, detail=api_err("Invalid or expired token", "INVALID_TOKEN"))
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"password_hash": hash_password(dto.password)}, "$unset": {"reset_token": "", "reset_token_expiry": ""}}
    )
    return api_ok({"message": "Password has been reset successfully."})

@app.post("/api/auth/verify-email")
async def verify_email(dto: VerifyEmailDTO):
    user = await db.users.find_one({
        "verify_token": dto.token,
        "verify_token_expiry": {"$gt": datetime.now(timezone.utc)}
    })
    if not user:
        raise HTTPException(status_code=400, detail=api_err("Invalid or expired token", "INVALID_TOKEN"))
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"email_verified": True}, "$unset": {"verify_token": "", "verify_token_expiry": ""}}
    )
    user["email_verified"] = True
    return api_ok({"message": "Email verified successfully!", "user": doc_to_user(user)})

@app.post("/api/auth/logout")
async def logout(user=Depends(get_current_user)):
    return api_ok({"message": "Logged out successfully"})

@app.get("/api/auth/me")
async def get_me(user=Depends(get_current_user)):
    return api_ok({"user": doc_to_user(user)})

@app.post("/api/auth/refresh")
async def refresh_token(request: Request):
    body = await request.json()
    refresh = body.get("refreshToken", "")
    try:
        payload = decode_token(refresh)
        user_id = payload.get("sub")
        user = await db.users.find_one({"_id": ObjectId(user_id)})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        new_access = create_token(str(user["_id"]), user["email"])
        new_refresh = create_token(str(user["_id"]), user["email"], timedelta(days=30))
        return api_ok({"accessToken": new_access, "refreshToken": new_refresh})
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

@app.post("/api/auth/resend-verification")
async def resend_verification(request: Request, user=Depends(get_current_user)):
    """Resend verification email"""
    if user.get("email_verified"):
        return api_ok({"message": "Email already verified"})
    
    # Generate new verification token
    verify_token = secrets.token_urlsafe(32)
    verify_expiry = datetime.now(timezone.utc) + timedelta(hours=24)
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"verify_token": verify_token, "verify_token_expiry": verify_expiry}}
    )
    
    # Send email
    asyncio.create_task(send_verification_email(user["email"], user.get("name", ""), verify_token))
    
    return api_ok({"message": "Verification email sent! Please check your inbox."})

# ─────────────────────────────────────────────
# GOOGLE OAUTH
# ─────────────────────────────────────────────
# Google OAuth session verification endpoint
GOOGLE_AUTH_URL = "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"

class GoogleAuthDTO(BaseModel):
    session_id: str

@app.post("/api/auth/google")
async def google_auth(dto: GoogleAuthDTO, response: Response):
    """Exchange Google OAuth session_id for user session"""
    try:
        # Call Google Auth to get user data
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                GOOGLE_AUTH_URL,
                headers={"X-Session-ID": dto.session_id},
                timeout=10.0
            )
            if resp.status_code != 200:
                logger.error(f"Google Auth error: {resp.status_code} - {resp.text}")
                raise HTTPException(status_code=401, detail=api_err("Google authentication failed", "GOOGLE_AUTH_FAILED"))
            
            google_data = resp.json()
        
        email = google_data.get("email", "").lower()
        name = google_data.get("name", "")
        picture = google_data.get("picture", "")
        
        if not email:
            raise HTTPException(status_code=400, detail=api_err("No email from Google", "NO_EMAIL"))
        
        # Check if user exists
        user = await db.users.find_one({"email": email})
        
        if user:
            # Update existing user with Google info
            await db.users.update_one(
                {"_id": user["_id"]},
                {"$set": {
                    "name": name or user.get("name", ""),
                    "avatar": picture,
                    "email_verified": True,  # Google emails are verified
                    "google_id": google_data.get("id"),
                    "last_login": datetime.now(timezone.utc),
                }}
            )
            user = await db.users.find_one({"_id": user["_id"]})
        else:
            # Create new user with 24h trial
            trial_expiry = datetime.now(timezone.utc) + timedelta(hours=24)
            user_doc = {
                "email": email,
                "name": name,
                "avatar": picture,
                "google_id": google_data.get("id"),
                "password_hash": "",  # No password for Google users
                "roles": ["viewer"],
                "email_verified": True,
                "subscription": "trial",
                "subscription_expiry": trial_expiry,
                "created_at": datetime.now(timezone.utc),
                "last_login": datetime.now(timezone.utc),
            }
            result = await db.users.insert_one(user_doc)
            user_doc["_id"] = result.inserted_id
            user = user_doc
        
        # Create JWT tokens
        access_token = create_token(str(user["_id"]), user["email"])
        refresh_token = create_token(str(user["_id"]), user["email"], timedelta(days=30))
        
        logger.info(f"Google auth successful for {email}")
        
        return api_ok({
            "user": doc_to_user(user),
            "accessToken": access_token,
            "refreshToken": refresh_token,
        })
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Google auth error: {e}")
        raise HTTPException(status_code=500, detail=api_err("Authentication failed", "AUTH_ERROR"))

# ─────────────────────────────────────────────
# SUBSCRIPTION CHECK MIDDLEWARE
# ─────────────────────────────────────────────
async def check_subscription(user: dict) -> dict:
    """Check if user has active subscription. Returns subscription status."""
    subscription = user.get("subscription", "free")
    expiry = user.get("subscription_expiry")
    
    if subscription == "free":
        return {"active": False, "reason": "No active subscription"}
    
    if expiry:
        # Handle both datetime and string formats
        if isinstance(expiry, str):
            expiry = datetime.fromisoformat(expiry.replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        
        if expiry < datetime.now(timezone.utc):
            return {"active": False, "reason": "Subscription expired", "expired_at": expiry.isoformat()}
    
    return {"active": True, "subscription": subscription, "expires_at": expiry.isoformat() if expiry else None}

async def require_active_subscription(user=Depends(get_current_user)) -> dict:
    """Dependency that requires an active subscription"""
    status = await check_subscription(user)
    if not status["active"]:
        raise HTTPException(
            status_code=402,  # Payment Required
            detail=api_err(f"Subscription required: {status.get('reason', 'No active subscription')}", "SUBSCRIPTION_REQUIRED")
        )
    return user


# ─────────────────────────────────────────────
# CRYPTO DATA FETCHING
# ─────────────────────────────────────────────
CG_HEADERS = {"x-cg-demo-api-key": COINGECKO_API_KEY} if COINGECKO_API_KEY else {}

def get_coingecko_markets(per_page=100) -> List[dict]:
    try:
        url = "https://api.coingecko.com/api/v3/coins/markets"
        params = {
            "vs_currency": "usd",
            "order": "volume_desc",
            "per_page": per_page,
            "page": 1,
            "price_change_percentage": "1h,24h,7d",
            "sparkline": "false",
        }
        r = requests.get(url, params=params, headers=CG_HEADERS, timeout=30)
        if r.status_code == 429:
            logger.warning("CoinGecko rate limit - waiting 60s")
            import time
            time.sleep(60)
            r = requests.get(url, params=params, headers=CG_HEADERS, timeout=30)
        r.raise_for_status()
        return r.json() or []
    except Exception as e:
        logger.error(f"CoinGecko error: {e}")
        return []

def get_lunarcrush_data(limit=50) -> List[dict]:
    """Try LunarCrush - gracefully fallback if subscription required"""
    try:
        url = "https://lunarcrush.com/api4/public/coins/list/v2"
        headers = {"Authorization": f"Bearer {LUNARCRUSH_API_KEY}"}
        params = {"sort": "galaxy_score", "limit": limit}
        r = requests.get(url, headers=headers, params=params, timeout=30)
        if r.status_code == 200:
            data = r.json()
            return data.get("data", [])
        logger.warning(f"LunarCrush unavailable (status {r.status_code}) - using CoinGecko only")
        return []
    except Exception as e:
        logger.error(f"LunarCrush error: {e}")
        return []

def get_fear_greed_index() -> dict:
    """Fear & Greed Index from alternative.me (free, no auth)"""
    try:
        r = requests.get("https://api.alternative.me/fng/?limit=1", timeout=10)
        if r.status_code == 200:
            data = r.json().get("data", [{}])[0]
            return {"value": int(data.get("value", 50)), "classification": data.get("value_classification", "Neutral")}
    except Exception:
        pass
    return {"value": 50, "classification": "Neutral"}

def get_coingecko_trending() -> List[str]:
    """Get trending coin symbols from CoinGecko (free)"""
    try:
        r = requests.get("https://api.coingecko.com/api/v3/search/trending", headers=CG_HEADERS, timeout=15)
        if r.status_code == 200:
            coins = r.json().get("coins", [])
            return [c["item"]["symbol"].upper() for c in coins]
    except Exception:
        pass
    return []

async def analyze_signals_with_ai(candidates: List[dict], fear_greed: dict = None, trending: List[str] = None) -> dict:
    """
    SCIENTIFIC PUMP/DUMP SIGNAL ANALYSIS
    
    Uses multiple quantitative indicators:
    1. Volume Spike Detection (Abnormal Volume = vol/mcap > 15% indicates institutional interest)
    2. Momentum Analysis (RSI-like: 1h vs 24h price action divergence)
    3. Market Sentiment Alignment (Fear & Greed correlation)
    4. Social Trending Factor (CoinGecko trending = retail interest)
    5. Price Action Patterns (Higher highs, lower lows detection)
    
    Signal Strength Formula:
    PUMP = (vol_score * 0.3) + (momentum_score * 0.35) + (trend_score * 0.2) + (sentiment_score * 0.15)
    DUMP = (vol_score * 0.25) + (decline_score * 0.4) + (selling_pressure * 0.2) + (sentiment_score * 0.15)
    """
    if not candidates:
        return {"pump_signals": [], "dump_signals": [], "market_summary": "No data available"}
    
    try:
        fg = fear_greed or {"value": 50, "classification": "Neutral"}
        trending_str = ", ".join(trending[:10]) if trending else "N/A"
        fg_value = fg.get("value", 50)
        
        # Pre-calculate scientific scores for each coin
        scored_candidates = []
        for c in candidates:
            vol_mcap = c.get('vol_mcap_ratio', 0)
            pc_1h = c.get('price_change_1h', 0)
            pc_24h = c.get('price_change_24h', 0)
            pc_7d = c.get('price_change_7d', 0)
            is_trending = c.get('is_trending', False)
            
            # VOLUME ANOMALY SCORE (0-100)
            # Normal vol/mcap is 3-8%, >15% is abnormal
            vol_score = min(100, (vol_mcap / 20) * 100) if vol_mcap > 5 else vol_mcap * 10
            
            # MOMENTUM SCORE (0-100) - Positive momentum when 1h > 24h change rate
            momentum_1h_normalized = pc_1h * 24  # Annualize 1h to compare with 24h
            momentum_divergence = momentum_1h_normalized - pc_24h
            momentum_score = min(100, max(0, 50 + momentum_divergence * 2))
            
            # TREND ALIGNMENT (0-100)
            # Bullish: all timeframes positive and accelerating
            trend_score = 0
            if pc_1h > 0 and pc_24h > 0:
                trend_score += 40
            if pc_1h > pc_24h / 24:  # 1h rate > 24h average rate = acceleration
                trend_score += 30
            if is_trending:
                trend_score += 30
            
            # SENTIMENT ALIGNMENT (0-100)
            # In Fear (FG<30): contrarian buys are stronger signals
            # In Greed (FG>70): momentum plays are stronger
            sentiment_boost = 0
            if fg_value < 30 and pc_1h > 0:  # Contrarian buy in fear
                sentiment_boost = 20
            elif fg_value > 60 and pc_1h > 2:  # Momentum in greed
                sentiment_boost = 15
            
            # PUMP SIGNAL STRENGTH
            pump_strength = (
                vol_score * 0.30 +
                momentum_score * 0.35 +
                trend_score * 0.20 +
                sentiment_boost * 0.15
            )
            
            # DUMP SIGNAL ANALYSIS
            # SELLING PRESSURE (0-100)
            selling_pressure = 0
            if pc_1h < 0 and pc_24h < 0:
                selling_pressure = min(100, abs(pc_1h) * 10 + abs(pc_24h) * 2)
            
            # DECLINE ACCELERATION
            decline_acceleration = 0
            if pc_1h < 0 and pc_1h < pc_24h / 24:  # Dropping faster than 24h average
                decline_acceleration = min(100, abs(pc_1h - pc_24h/24) * 15)
            
            # HIGH VOLUME DUMP (panic selling)
            dump_vol_score = vol_score if pc_1h < -2 else 0
            
            dump_strength = (
                dump_vol_score * 0.25 +
                decline_acceleration * 0.40 +
                selling_pressure * 0.20 +
                (15 if fg_value > 70 else 0)  # Dumps in extreme greed are significant
            )
            
            scored_candidates.append({
                **c,
                "pump_strength": round(pump_strength, 1),
                "dump_strength": round(dump_strength, 1),
                "vol_score": round(vol_score, 1),
                "momentum_score": round(momentum_score, 1),
            })
        
        # Select top pump candidates (strength > 50)
        pump_candidates = sorted(
            [c for c in scored_candidates if c["pump_strength"] > 45 and c.get("price_change_1h", 0) > 0],
            key=lambda x: x["pump_strength"],
            reverse=True
        )[:15]
        
        # Select top dump candidates (strength > 40)
        dump_candidates = sorted(
            [c for c in scored_candidates if c["dump_strength"] > 35 and c.get("price_change_1h", 0) < 0],
            key=lambda x: x["dump_strength"],
            reverse=True
        )[:10]
        
        chat = genai.GenerativeModel(
            model_name="gemini-2.0-flash",
            system_instruction="""You are a quantitative crypto analyst. You analyze PRE-SCORED signals and provide scientific explanations.
You MUST respond ONLY in valid JSON format, with no text before or after the JSON.
All text in the response MUST be in English.
Your analysis must be SPECIFIC with exact numbers and technical reasoning - no vague statements."""
        )
        
        pump_data = "\n".join([
            f"{c['symbol']}: pump_score={c['pump_strength']}, price=${c['price']:.6f}, "
            f"vol/mcap={c['vol_mcap_ratio']:.1f}%, 1h={c['price_change_1h']:+.2f}%, "
            f"24h={c['price_change_24h']:+.2f}%, momentum={c['momentum_score']:.0f}, "
            f"trending={'YES' if c.get('is_trending') else 'no'}"
            for c in pump_candidates
        ]) if pump_candidates else "No strong pump signals detected"
        
        dump_data = "\n".join([
            f"{c['symbol']}: dump_score={c['dump_strength']}, price=${c['price']:.6f}, "
            f"vol/mcap={c['vol_mcap_ratio']:.1f}%, 1h={c['price_change_1h']:+.2f}%, "
            f"24h={c['price_change_24h']:+.2f}%"
            for c in dump_candidates
        ]) if dump_candidates else "No strong dump signals detected"
        
        prompt = f"""Analyze these PRE-SCORED cryptocurrency signals and provide SCIENTIFIC explanations.

MARKET CONDITIONS:
- Fear & Greed Index: {fg_value}/100 ({fg['classification']})
- Market sentiment: {'EXTREME FEAR - contrarian opportunities' if fg_value < 25 else 'FEAR - cautious accumulation zone' if fg_value < 40 else 'NEUTRAL' if fg_value < 60 else 'GREED - momentum favored' if fg_value < 75 else 'EXTREME GREED - high reversal risk'}
- Trending coins: {trending_str}

PUMP CANDIDATES (pre-scored by algorithm):
{pump_data}

DUMP CANDIDATES (pre-scored by algorithm):
{dump_data}

Return JSON with this EXACT structure. For each signal, provide SPECIFIC technical reasoning with exact numbers:

{{
  "pump_signals": [
    {{
      "symbol": "BTC",
      "signal_strength": 85,
      "reason": "Volume spike at X% (3x normal), 1h momentum +Y% outpacing 24h average by Zx. RSI-equivalent shows bullish divergence. Probability of continued upward movement: W%.",
      "technical_factors": "Abnormal volume accumulation, positive momentum divergence, Fear & Greed alignment",
      "confidence": "high",
      "risk_level": "medium",
      "timeframe": "4-12 hours"
    }}
  ],
  "dump_signals": [
    {{
      "symbol": "ETH",
      "signal_strength": 70,
      "reason": "Accelerating decline: 1h drop of X% is Yx faster than 24h average rate. High volume (Z%) suggests institutional selling. Support breakdown likely.",
      "technical_factors": "Selling pressure acceleration, volume-confirmed decline, momentum breakdown",
      "confidence": "medium",
      "risk_level": "high",
      "timeframe": "2-8 hours"
    }}
  ],
  "market_summary": "Fear & Greed at [FG_VALUE] signals [SENTIMENT]. [N] coins showing pump potential, [M] showing dump risk. Key observation: [specific technical insight]."
}}

IMPORTANT:
- Use EXACT numbers from the data (don't round too much)
- Explain WHY each signal is significant using the pre-calculated scores
- Maximum 8 pump signals and 4 dump signals, sorted by signal_strength DESC
- Confidence levels: high (>75 score), medium (50-75), low (<50)
- Risk levels based on volatility and market conditions"""
        
        response = await asyncio.to_thread(lambda: chat.generate_content(prompt).text)
        
        # Parse JSON response
        import json as json_lib
        response_clean = response.strip()
        if response_clean.startswith("```"):
            lines = response_clean.split("\n")
            response_clean = "\n".join([l for l in lines if not l.startswith("```")])
        
        result = json_lib.loads(response_clean)
        return result
    except Exception as e:
        logger.error(f"AI analysis error: {e}")
        return {"pump_signals": [], "dump_signals": [], "market_summary": "AI analysis temporarily unavailable"}

async def fetch_and_store_signals():
    """Main job: fetch data, analyze with AI, store results"""
    logger.info("Starting crypto signal fetch job...")
    
    try:
        # Fetch data in parallel
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as executor:
            cg_future = executor.submit(get_coingecko_markets, 100)
            lc_future = executor.submit(get_lunarcrush_data, 50)
            fg_future = executor.submit(get_fear_greed_index)
            trending_future = executor.submit(get_coingecko_trending)
            
            cg_data = cg_future.result()
            lc_data = lc_future.result()
            fear_greed = fg_future.result()
            trending_symbols = trending_future.result()
        
        # Build LunarCrush lookup by symbol
        lc_lookup: Dict[str, dict] = {}
        for coin in lc_data:
            sym = (coin.get("symbol") or coin.get("s") or "").upper()
            if sym:
                lc_lookup[sym] = coin
        
        # Merge data - FILTER OUT INVALID COINS
        candidates = []
        for coin in cg_data:
            sym = coin.get("symbol", "").upper()
            
            # STRICT VALIDATION - Skip coins with invalid/zero data
            price = coin.get("current_price") or 0
            vol = coin.get("total_volume") or 0
            mcap = coin.get("market_cap") or 0
            
            # Skip if price is 0 or extremely low (likely dead/scam coins)
            if price <= 0 or price < 0.0000001:
                continue
            
            # Skip if no volume (dead coins)
            if vol <= 0:
                continue
                
            # Skip if no market cap (not a real trading coin)
            if mcap <= 0:
                continue
            
            # Skip if market cap is suspiciously low (< $100k - likely scam/meme)
            if mcap < 100000:
                continue
            
            lc = lc_lookup.get(sym, {})
            
            # Extract price changes
            pc = coin.get("price_change_percentage_1h_in_currency") or coin.get("price_change_percentage_1h") or 0
            pc24 = coin.get("price_change_percentage_24h") or 0
            pc7d = coin.get("price_change_percentage_7d_in_currency") or coin.get("price_change_percentage_7d") or 0
            
            vol_mcap_ratio = (vol / mcap * 100) if mcap > 0 else 0
            
            candidates.append({
                "id": coin.get("id", ""),
                "symbol": sym,
                "name": coin.get("name", ""),
                "price": price,
                "market_cap": mcap,
                "volume_24h": vol,
                "vol_mcap_ratio": round(vol_mcap_ratio, 2),
                "price_change_1h": round(float(pc), 2) if pc else 0,
                "price_change_24h": round(float(pc24), 2) if pc24 else 0,
                "price_change_7d": round(float(pc7d), 2) if pc7d else 0,
                "image": coin.get("image"),
                "is_trending": sym in trending_symbols,
                # LunarCrush data (0 if not available)
                "social_volume": lc.get("social_volume") or lc.get("sv") or 0,
                "sentiment": lc.get("sentiment") or lc.get("ss") or 0,
                "galaxy_score": lc.get("galaxy_score") or lc.get("gs") or 0,
            })
        
        logger.info(f"Filtered to {len(candidates)} valid coins from {len(cg_data)} total")
        
        # AI Analysis with all available data
        ai_result = await analyze_signals_with_ai(candidates, fear_greed, trending_symbols)
        
        # Enrich signals with market data
        cg_lookup = {c["symbol"].upper(): c for c in candidates}
        
        def enrich_signal(sig: dict, signal_type: str) -> dict:
            sym = sig.get("symbol", "").upper()
            market = cg_lookup.get(sym, {})
            
            # Skip if no market data found (AI hallucinated a coin)
            if not market:
                return None
            
            # Skip if price is 0 or invalid
            price = market.get("price") or 0
            if price <= 0:
                return None
                
            return {
                **sig,
                "signal_type": signal_type,
                "symbol": sym,
                "name": market.get("name", sym),
                "price": price,
                "price_change_1h": market.get("price_change_1h"),
                "price_change_24h": market.get("price_change_24h"),
                "volume_24h": market.get("volume_24h"),
                "social_volume": market.get("social_volume"),
                "sentiment": market.get("sentiment"),
                "galaxy_score": market.get("galaxy_score"),
                "image": market.get("image"),
                "is_trending": market.get("is_trending", False),
                "timestamp": datetime.now(timezone.utc),
            }
        
        # Filter out None (invalid signals)
        pump_signals = [s for s in [enrich_signal(s, "pump") for s in ai_result.get("pump_signals", [])] if s is not None]
        dump_signals = [s for s in [enrich_signal(s, "dump") for s in ai_result.get("dump_signals", [])] if s is not None]
        
        if pump_signals or dump_signals:
            snapshot = {
                "timestamp": datetime.now(timezone.utc),
                "pump_signals": pump_signals,
                "dump_signals": dump_signals,
                "market_summary": ai_result.get("market_summary", ""),
                "coins_analyzed": len(candidates),
                "fear_greed": fear_greed,
                "trending": trending_symbols[:10],
            }
            await db.signal_snapshots.insert_one(snapshot)
            
            # Send email alerts for strong signals
            asyncio.create_task(check_and_send_alerts(pump_signals, dump_signals))
            
            # Keep only last 48 snapshots
            count = await db.signal_snapshots.count_documents({})
            if count > 48:
                oldest = await db.signal_snapshots.find({}).sort("timestamp", 1).limit(count - 48).to_list(length=100)
                old_ids = [d["_id"] for d in oldest]
                await db.signal_snapshots.delete_many({"_id": {"$in": old_ids}})
        
        logger.info(f"Signal job complete: {len(pump_signals)} pump, {len(dump_signals)} dump signals")
        
    except Exception as e:
        logger.exception(f"Signal fetch job error: {e}")

# ─────────────────────────────────────────────
# CRYPTO SIGNAL ENDPOINTS
# ─────────────────────────────────────────────
def serialize_signal(s: dict) -> dict:
    """Remove MongoDB _id and serialize datetime"""
    s.pop("_id", None)
    if isinstance(s.get("timestamp"), datetime):
        s["timestamp"] = s["timestamp"].isoformat()
    return s

@app.get("/api/crypto/signals")
async def get_signals(user=Depends(get_optional_user)):
    """Get latest pump/dump signals"""
    # Get latest snapshot
    snapshot = await db.signal_snapshots.find_one({}, sort=[("timestamp", -1)])
    
    if not snapshot:
        # Return empty if no data yet
        return api_ok({
            "pump_signals": [],
            "dump_signals": [],
            "market_summary": "Signals are being processed. Please check back in a few minutes.",
            "last_updated": None,
            "coins_analyzed": 0,
        })
    
    # Check subscription for full access
    has_access = True  # Default to true for unauthenticated users (limited view)
    subscription_expired = False
    
    if user:
        sub = user.get("subscription", "free")
        sub_expiry = user.get("subscription_expiry")
        
        if sub in ("monthly", "annual"):
            has_access = True
        elif sub == "trial":
            if sub_expiry:
                # Handle timezone
                if isinstance(sub_expiry, str):
                    sub_expiry = datetime.fromisoformat(sub_expiry.replace("Z", "+00:00"))
                if hasattr(sub_expiry, 'tzinfo') and sub_expiry.tzinfo is None:
                    sub_expiry = sub_expiry.replace(tzinfo=timezone.utc)
                
                if datetime.now(timezone.utc) < sub_expiry:
                    has_access = True
                else:
                    # Trial expired - block access
                    has_access = False
                    subscription_expired = True
            else:
                has_access = False
                subscription_expired = True
        else:
            # Free tier - no access
            has_access = False
            subscription_expired = True
    
    # If subscription expired, return 402 Payment Required
    if subscription_expired and user:
        raise HTTPException(
            status_code=402,
            detail=api_err("Your free trial has expired. Please subscribe to continue.", "SUBSCRIPTION_EXPIRED")
        )
    
    pump = [serialize_signal(dict(s)) for s in snapshot.get("pump_signals", [])]
    dump = [serialize_signal(dict(s)) for s in snapshot.get("dump_signals", [])]
    
    # Free users see first 3 signals blurred (frontend handles blur)
    return api_ok({
        "pump_signals": pump,
        "dump_signals": dump,
        "market_summary": snapshot.get("market_summary", ""),
        "last_updated": snapshot["timestamp"].isoformat() if isinstance(snapshot.get("timestamp"), datetime) else snapshot.get("timestamp"),
        "coins_analyzed": snapshot.get("coins_analyzed", 0),
        "has_full_access": has_access,
        "fear_greed": snapshot.get("fear_greed"),
        "trending": snapshot.get("trending", []),
    })

@app.get("/api/crypto/history")
async def get_history(limit: int = 24, user=Depends(get_current_user)):
    """Get historical signals (last N snapshots)"""
    snapshots = await db.signal_snapshots.find({}).sort("timestamp", -1).limit(limit).to_list(length=limit)
    
    result = []
    for snap in snapshots:
        result.append({
            "timestamp": snap["timestamp"].isoformat() if isinstance(snap.get("timestamp"), datetime) else snap.get("timestamp"),
            "pump_count": len(snap.get("pump_signals", [])),
            "dump_count": len(snap.get("dump_signals", [])),
            "market_summary": snap.get("market_summary", ""),
            "coins_analyzed": snap.get("coins_analyzed", 0),
        })
    
    return api_ok({"history": result})

@app.get("/api/crypto/snapshots")
async def get_snapshots(limit: int = 24, user=Depends(get_optional_user)):
    """Get detailed signal snapshots for timeline view"""
    snapshots = await db.signal_snapshots.find({}).sort("timestamp", -1).limit(limit).to_list(length=limit)
    
    result = []
    for snap in snapshots:
        snap.pop("_id", None)
        if isinstance(snap.get("timestamp"), datetime):
            snap["timestamp"] = snap["timestamp"].isoformat()
        # Serialize signals
        for s in snap.get("pump_signals", []):
            if isinstance(s.get("timestamp"), datetime):
                s["timestamp"] = s["timestamp"].isoformat()
        for s in snap.get("dump_signals", []):
            if isinstance(s.get("timestamp"), datetime):
                s["timestamp"] = s["timestamp"].isoformat()
        result.append(snap)
    
    return api_ok({"snapshots": result})

# ─────────────────────────────────────────────
# WATCHLIST & ALERTS
# ─────────────────────────────────────────────
class WatchlistItem(BaseModel):
    symbol: str
    alertEnabled: bool = False
    alertThreshold: int = 80

class WatchlistUpdate(BaseModel):
    items: List[WatchlistItem]

@app.get("/api/user/watchlist")
async def get_watchlist(user=Depends(get_current_user)):
    """Get user's watchlist"""
    watchlist = user.get("watchlist", [])
    return api_ok({"watchlist": watchlist})

@app.post("/api/user/watchlist")
async def update_watchlist(data: WatchlistUpdate, user=Depends(get_current_user)):
    """Update user's watchlist"""
    watchlist_data = [item.dict() for item in data.items]
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"watchlist": watchlist_data}}
    )
    return api_ok({"message": "Watchlist updated", "watchlist": watchlist_data})

@app.post("/api/user/watchlist/add")
async def add_to_watchlist(item: WatchlistItem, user=Depends(get_current_user)):
    """Add coin to watchlist"""
    watchlist = user.get("watchlist", [])
    # Check if already exists
    if any(w.get("symbol") == item.symbol.upper() for w in watchlist):
        return api_ok({"message": "Already in watchlist", "watchlist": watchlist})
    
    new_item = {
        "symbol": item.symbol.upper(),
        "alertEnabled": item.alertEnabled,
        "alertThreshold": item.alertThreshold,
        "addedAt": datetime.now(timezone.utc).isoformat(),
    }
    watchlist.append(new_item)
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"watchlist": watchlist}}
    )
    return api_ok({"message": f"Added {item.symbol} to watchlist", "watchlist": watchlist})

@app.delete("/api/user/watchlist/{symbol}")
async def remove_from_watchlist(symbol: str, user=Depends(get_current_user)):
    """Remove coin from watchlist"""
    watchlist = user.get("watchlist", [])
    watchlist = [w for w in watchlist if w.get("symbol") != symbol.upper()]
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {"watchlist": watchlist}}
    )
    return api_ok({"message": f"Removed {symbol} from watchlist", "watchlist": watchlist})

# ─────────────────────────────────────────────
# EMAIL ALERTS FOR STRONG SIGNALS
# ─────────────────────────────────────────────
async def send_signal_alert_email(email: str, name: str, signal: dict, signal_type: str):
    """Send email alert for strong signals"""
    html = f"""
    <div style="font-family:sans-serif;max-width:600px;margin:0 auto;padding:24px;background:#0f172a;color:#fff;border-radius:12px">
      <div style="text-align:center;margin-bottom:20px">
        <img src="{LOGO_URL}" alt="PumpRadar" style="width:48px;height:48px;border-radius:10px" />
      </div>
      <h2 style="color:{'#10b981' if signal_type == 'pump' else '#ef4444'};margin-bottom:16px;text-align:center">
        {'🚀 PUMP' if signal_type == 'pump' else '📉 DUMP'} Alert: {signal.get('symbol')}
      </h2>
      <p>Hi {name},</p>
      <p>A strong {signal_type.upper()} signal has been detected:</p>
      <div style="background:#1e293b;padding:16px;border-radius:8px;margin:16px 0">
        <p style="margin:0 0 8px 0"><strong>Coin:</strong> {signal.get('symbol')} ({signal.get('name', '')})</p>
        <p style="margin:0 0 8px 0"><strong>Signal Strength:</strong> <span style="color:{'#10b981' if signal_type == 'pump' else '#ef4444'};font-size:18px">{signal.get('signal_strength', 0)}%</span></p>
        <p style="margin:0 0 8px 0"><strong>Price:</strong> ${signal.get('price', 0)}</p>
        <p style="margin:0 0 8px 0"><strong>1h Change:</strong> {signal.get('price_change_1h', 0):+.2f}%</p>
        <p style="margin:0"><strong>Reason:</strong> {signal.get('reason', '')[:200]}</p>
      </div>
      <p style="color:#94a3b8;font-size:12px">This is not financial advice. Always do your own research.</p>
      <a href="{APP_URL}/coin/{signal.get('symbol')}?type={signal_type}" 
         style="display:inline-block;background:{'#10b981' if signal_type == 'pump' else '#ef4444'};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;margin-top:16px">
        View Details
      </a>
    </div>"""
    try:
        await asyncio.to_thread(resend.Emails.send, {
            "from": f"PumpRadar Alerts <{SENDER_EMAIL}>",
            "to": [email],
            "subject": f"{'🚀' if signal_type == 'pump' else '📉'} {signal_type.upper()} Alert: {signal.get('symbol')} ({signal.get('signal_strength')}%)",
            "html": html,
        })
        logger.info(f"Alert email sent to {email} for {signal.get('symbol')}")
    except Exception as e:
        logger.error(f"Alert email error: {e}")

async def check_and_send_alerts(pump_signals: List[dict], dump_signals: List[dict]):
    """Check for strong signals and send alerts to users with enabled notifications"""
    # Get users with alert enabled (Pro subscribers)
    pro_users = await db.users.find({
        "subscription": {"$in": ["monthly", "annual"]},
        "email_alerts_enabled": True,
    }).to_list(length=1000)
    
    if not pro_users:
        return
    
    # Get strong signals (>= 85% strength)
    strong_pumps = [s for s in pump_signals if s.get("signal_strength", 0) >= 85]
    strong_dumps = [s for s in dump_signals if s.get("signal_strength", 0) >= 85]
    
    for user in pro_users:
        email = user.get("email")
        name = user.get("name", "Trader")
        watchlist = user.get("watchlist", [])
        
        # Check watchlist alerts
        for item in watchlist:
            if not item.get("alertEnabled"):
                continue
            symbol = item.get("symbol", "").upper()
            threshold = item.get("alertThreshold", 80)
            
            # Check pumps
            for signal in pump_signals:
                if signal.get("symbol", "").upper() == symbol and signal.get("signal_strength", 0) >= threshold:
                    asyncio.create_task(send_signal_alert_email(email, name, signal, "pump"))
            
            # Check dumps
            for signal in dump_signals:
                if signal.get("symbol", "").upper() == symbol and signal.get("signal_strength", 0) >= threshold:
                    asyncio.create_task(send_signal_alert_email(email, name, signal, "dump"))
        
        # Send alerts for any very strong signal (>= 85%) if user has global alerts enabled
        if user.get("global_alerts_enabled"):
            for signal in strong_pumps[:3]:  # Max 3 alerts
                asyncio.create_task(send_signal_alert_email(email, name, signal, "pump"))
            for signal in strong_dumps[:2]:  # Max 2 alerts
                asyncio.create_task(send_signal_alert_email(email, name, signal, "dump"))

# Alert settings endpoints
class AlertSettings(BaseModel):
    email_alerts_enabled: bool = False
    global_alerts_enabled: bool = False

@app.get("/api/user/alerts")
async def get_alert_settings(user=Depends(get_current_user)):
    """Get user's alert settings"""
    return api_ok({
        "email_alerts_enabled": user.get("email_alerts_enabled", False),
        "global_alerts_enabled": user.get("global_alerts_enabled", False),
    })

@app.post("/api/user/alerts")
async def update_alert_settings(settings: AlertSettings, user=Depends(get_current_user)):
    """Update user's alert settings"""
    # Only Pro users can enable alerts
    sub = user.get("subscription", "free")
    if sub not in ("monthly", "annual"):
        raise HTTPException(status_code=402, detail=api_err("Pro subscription required for email alerts", "SUBSCRIPTION_REQUIRED"))
    
    await db.users.update_one(
        {"_id": user["_id"]},
        {"$set": {
            "email_alerts_enabled": settings.email_alerts_enabled,
            "global_alerts_enabled": settings.global_alerts_enabled,
        }}
    )
    return api_ok({"message": "Alert settings updated"})

# ─────────────────────────────────────────────
# SIGNAL ACCURACY TRACKER
# ─────────────────────────────────────────────
async def track_signal_accuracy():
    """
    Track if PUMP/DUMP predictions came true after 1h, 4h, 24h.
    Called hourly by scheduler.
    """
    try:
        # Get signals that need accuracy check
        now = datetime.now(timezone.utc)
        
        # Find predictions from 1h, 4h, 24h ago that haven't been verified
        time_windows = [
            {"hours": 1, "field": "accuracy_1h"},
            {"hours": 4, "field": "accuracy_4h"},
            {"hours": 24, "field": "accuracy_24h"},
        ]
        
        for window in time_windows:
            target_time = now - timedelta(hours=window["hours"])
            field = window["field"]
            
            # Find signals from that time window that don't have this accuracy field
            snapshots = await db.signal_snapshots.find({
                "timestamp": {
                    "$gte": target_time - timedelta(minutes=30),
                    "$lte": target_time + timedelta(minutes=30)
                },
                field: {"$exists": False}
            }).to_list(length=10)
            
            for snapshot in snapshots:
                pump_signals = snapshot.get("pump_signals", [])
                dump_signals = snapshot.get("dump_signals", [])
                
                # Get current prices for these coins
                correct_pumps = 0
                total_pumps = len(pump_signals)
                correct_dumps = 0
                total_dumps = len(dump_signals)
                
                for signal in pump_signals:
                    symbol = signal.get("symbol", "").lower()
                    original_price = signal.get("price", 0)
                    
                    # Fetch current price
                    try:
                        resp = requests.get(
                            f"https://api.coingecko.com/api/v3/simple/price",
                            params={"ids": signal.get("coin_id", symbol), "vs_currencies": "usd"},
                            timeout=5
                        )
                        if resp.status_code == 200:
                            data = resp.json()
                            current_price = list(data.values())[0].get("usd", 0) if data else 0
                            
                            # PUMP is correct if price increased
                            if current_price > original_price:
                                correct_pumps += 1
                    except:
                        pass
                
                for signal in dump_signals:
                    symbol = signal.get("symbol", "").lower()
                    original_price = signal.get("price", 0)
                    
                    try:
                        resp = requests.get(
                            f"https://api.coingecko.com/api/v3/simple/price",
                            params={"ids": signal.get("coin_id", symbol), "vs_currencies": "usd"},
                            timeout=5
                        )
                        if resp.status_code == 200:
                            data = resp.json()
                            current_price = list(data.values())[0].get("usd", 0) if data else 0
                            
                            # DUMP is correct if price decreased
                            if current_price < original_price:
                                correct_dumps += 1
                    except:
                        pass
                
                # Calculate accuracy
                pump_accuracy = (correct_pumps / total_pumps * 100) if total_pumps > 0 else 0
                dump_accuracy = (correct_dumps / total_dumps * 100) if total_dumps > 0 else 0
                overall_accuracy = ((correct_pumps + correct_dumps) / (total_pumps + total_dumps) * 100) if (total_pumps + total_dumps) > 0 else 0
                
                # Store accuracy data
                await db.signal_snapshots.update_one(
                    {"_id": snapshot["_id"]},
                    {"$set": {
                        field: {
                            "pump_accuracy": round(pump_accuracy, 1),
                            "dump_accuracy": round(dump_accuracy, 1),
                            "overall_accuracy": round(overall_accuracy, 1),
                            "correct_pumps": correct_pumps,
                            "total_pumps": total_pumps,
                            "correct_dumps": correct_dumps,
                            "total_dumps": total_dumps,
                            "verified_at": now.isoformat(),
                        }
                    }}
                )
                
                logger.info(f"Accuracy tracked for {window['hours']}h: PUMP {pump_accuracy:.1f}%, DUMP {dump_accuracy:.1f}%")
                
    except Exception as e:
        logger.error(f"Accuracy tracking error: {e}")

@app.get("/api/crypto/accuracy")
async def get_signal_accuracy(user=Depends(get_optional_user)):
    """Get signal accuracy statistics"""
    # Get last 24 snapshots with accuracy data
    snapshots = await db.signal_snapshots.find({
        "$or": [
            {"accuracy_1h": {"$exists": True}},
            {"accuracy_4h": {"$exists": True}},
            {"accuracy_24h": {"$exists": True}},
        ]
    }).sort("timestamp", -1).limit(48).to_list(length=48)
    
    # Aggregate accuracy stats
    stats_1h = {"pump": [], "dump": [], "overall": []}
    stats_4h = {"pump": [], "dump": [], "overall": []}
    stats_24h = {"pump": [], "dump": [], "overall": []}
    
    for snap in snapshots:
        if snap.get("accuracy_1h"):
            acc = snap["accuracy_1h"]
            stats_1h["pump"].append(acc.get("pump_accuracy", 0))
            stats_1h["dump"].append(acc.get("dump_accuracy", 0))
            stats_1h["overall"].append(acc.get("overall_accuracy", 0))
        
        if snap.get("accuracy_4h"):
            acc = snap["accuracy_4h"]
            stats_4h["pump"].append(acc.get("pump_accuracy", 0))
            stats_4h["dump"].append(acc.get("dump_accuracy", 0))
            stats_4h["overall"].append(acc.get("overall_accuracy", 0))
        
        if snap.get("accuracy_24h"):
            acc = snap["accuracy_24h"]
            stats_24h["pump"].append(acc.get("pump_accuracy", 0))
            stats_24h["dump"].append(acc.get("dump_accuracy", 0))
            stats_24h["overall"].append(acc.get("overall_accuracy", 0))
    
    def avg(lst):
        return round(sum(lst) / len(lst), 1) if lst else 0
    
    return api_ok({
        "accuracy_1h": {
            "pump": avg(stats_1h["pump"]),
            "dump": avg(stats_1h["dump"]),
            "overall": avg(stats_1h["overall"]),
            "samples": len(stats_1h["overall"]),
        },
        "accuracy_4h": {
            "pump": avg(stats_4h["pump"]),
            "dump": avg(stats_4h["dump"]),
            "overall": avg(stats_4h["overall"]),
            "samples": len(stats_4h["overall"]),
        },
        "accuracy_24h": {
            "pump": avg(stats_24h["pump"]),
            "dump": avg(stats_24h["dump"]),
            "overall": avg(stats_24h["overall"]),
            "samples": len(stats_24h["overall"]),
        },
        "last_updated": snapshots[0]["timestamp"].isoformat() if snapshots else None,
    })

# ─────────────────────────────────────────────
# DAILY MARKET OPEN EMAILS (PRO FEATURE)
# ─────────────────────────────────────────────
async def send_market_open_email(market: str):
    """
    Send best signal candidates email at market open.
    Called by scheduler at:
    - London: 08:00 UTC (LSE opens)
    - New York: 14:30 UTC (NYSE opens at 9:30 AM EST)
    """
    try:
        # Get latest signals
        snapshot = await db.signal_snapshots.find_one({}, sort=[("timestamp", -1)])
        if not snapshot:
            logger.warning(f"No signals available for {market} market open email")
            return
        
        pump_signals = snapshot.get("pump_signals", [])[:5]  # Top 5 pumps
        dump_signals = snapshot.get("dump_signals", [])[:3]  # Top 3 dumps
        fear_greed = snapshot.get("fear_greed", {})
        market_summary = snapshot.get("market_summary", "")
        
        if not pump_signals and not dump_signals:
            return
        
        # Get all Pro subscribers with daily emails enabled
        pro_users = await db.users.find({
            "subscription": {"$in": ["monthly", "annual"]},
            "daily_market_emails": {"$ne": False},  # Default to True if not set
        }).to_list(length=1000)
        
        if not pro_users:
            return
        
        market_name = "London Stock Exchange" if market == "london" else "New York Stock Exchange"
        market_emoji = "🇬🇧" if market == "london" else "🇺🇸"
        
        for user in pro_users:
            email = user.get("email")
            name = user.get("name", "Trader")
            
            # Build email content
            pump_html = ""
            for i, s in enumerate(pump_signals, 1):
                pump_html += f"""
                <tr>
                  <td style="padding:8px;border-bottom:1px solid #334155">{i}. <strong>{s.get('symbol')}</strong></td>
                  <td style="padding:8px;border-bottom:1px solid #334155;color:#10b981">{s.get('signal_strength', 0)}%</td>
                  <td style="padding:8px;border-bottom:1px solid #334155">${s.get('price', 0):.6f}</td>
                  <td style="padding:8px;border-bottom:1px solid #334155;color:#10b981">+{s.get('price_change_1h', 0):.2f}%</td>
                </tr>"""
            
            dump_html = ""
            for i, s in enumerate(dump_signals, 1):
                dump_html += f"""
                <tr>
                  <td style="padding:8px;border-bottom:1px solid #334155">{i}. <strong>{s.get('symbol')}</strong></td>
                  <td style="padding:8px;border-bottom:1px solid #334155;color:#ef4444">{s.get('signal_strength', 0)}%</td>
                  <td style="padding:8px;border-bottom:1px solid #334155">${s.get('price', 0):.6f}</td>
                  <td style="padding:8px;border-bottom:1px solid #334155;color:#ef4444">{s.get('price_change_1h', 0):.2f}%</td>
                </tr>"""
            
            html = f"""
            <div style="font-family:sans-serif;max-width:650px;margin:0 auto;padding:24px;background:#0f172a;color:#fff;border-radius:12px">
              <div style="text-align:center;margin-bottom:24px">
                <img src="{LOGO_URL}" alt="PumpRadar" style="width:56px;height:56px;border-radius:12px;margin-bottom:12px" />
                <h1 style="color:#fff;margin:0">{market_emoji} {market_name} Opens</h1>
                <p style="color:#94a3b8;margin:8px 0 0 0">Daily Signal Report for {name}</p>
              </div>
              
              <div style="background:#1e293b;padding:16px;border-radius:8px;margin-bottom:20px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <span style="color:#94a3b8">Fear & Greed Index</span>
                  <span style="font-size:24px;font-weight:bold;color:{'#ef4444' if fear_greed.get('value', 50) < 30 else '#f59e0b' if fear_greed.get('value', 50) < 50 else '#10b981'}">{fear_greed.get('value', 'N/A')}/100</span>
                </div>
                <p style="color:#cbd5e1;margin:8px 0 0 0;font-size:14px">{fear_greed.get('classification', 'N/A')}</p>
              </div>
              
              <h2 style="color:#10b981;margin:24px 0 12px 0;font-size:18px">🚀 Top PUMP Candidates</h2>
              <table style="width:100%;border-collapse:collapse;background:#1e293b;border-radius:8px;overflow:hidden">
                <thead>
                  <tr style="background:#334155">
                    <th style="padding:10px;text-align:left;color:#94a3b8">Coin</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">Signal</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">Price</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">1h</th>
                  </tr>
                </thead>
                <tbody>{pump_html}</tbody>
              </table>
              
              <h2 style="color:#ef4444;margin:24px 0 12px 0;font-size:18px">📉 DUMP Warnings</h2>
              <table style="width:100%;border-collapse:collapse;background:#1e293b;border-radius:8px;overflow:hidden">
                <thead>
                  <tr style="background:#334155">
                    <th style="padding:10px;text-align:left;color:#94a3b8">Coin</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">Signal</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">Price</th>
                    <th style="padding:10px;text-align:left;color:#94a3b8">1h</th>
                  </tr>
                </thead>
                <tbody>{dump_html}</tbody>
              </table>
              
              <div style="background:#1e293b;padding:16px;border-radius:8px;margin-top:20px">
                <h3 style="color:#6366f1;margin:0 0 8px 0;font-size:14px">🤖 AI Market Summary</h3>
                <p style="color:#cbd5e1;margin:0;font-size:14px;line-height:1.5">{market_summary[:400]}...</p>
              </div>
              
              <div style="text-align:center;margin-top:24px">
                <a href="{APP_URL}/dashboard" 
                   style="display:inline-block;background:linear-gradient(135deg,#10b981,#059669);color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold">
                  View Full Dashboard →
                </a>
              </div>
              
              <p style="color:#64748b;font-size:11px;text-align:center;margin-top:24px;border-top:1px solid #334155;padding-top:16px">
                This is not financial advice. Always do your own research.<br>
                <a href="{APP_URL}/settings" style="color:#6366f1">Manage email preferences</a>
              </p>
            </div>"""
            
            try:
                await asyncio.to_thread(resend.Emails.send, {
                    "from": f"PumpRadar <{SENDER_EMAIL}>",
                    "to": [email],
                    "subject": f"{market_emoji} {market_name} Opens - Top Signals for Today",
                    "html": html,
                })
                logger.info(f"Market open email sent to {email} for {market}")
            except Exception as e:
                logger.error(f"Market open email error for {email}: {e}")
        
        logger.info(f"{market.upper()} market open emails sent to {len(pro_users)} Pro users")
        
    except Exception as e:
        logger.exception(f"Market open email job error: {e}")

async def send_london_market_email():
    """Wrapper for London market open email"""
    await send_market_open_email("london")

async def send_nyse_market_email():
    """Wrapper for NYSE market open email"""
    await send_market_open_email("nyse")

@app.post("/api/crypto/refresh")
async def manual_refresh(background_tasks: BackgroundTasks, user=Depends(get_current_user)):
    """Manual trigger for signal refresh (admin only)"""
    background_tasks.add_task(fetch_and_store_signals)
    return api_ok({"message": "Signal refresh triggered"})

# ─────────────────────────────────────────────
# SUBSCRIPTION / STRIPE
# ─────────────────────────────────────────────
SUBSCRIPTION_PLANS = {
    "trial": {"name": "Trial 24h", "price": 0.0, "currency": "usd", "duration_days": 1},
    "monthly": {"name": "Pro Monthly", "price": 29.99, "currency": "usd", "duration_days": 30},
    "annual": {"name": "Pro Annual", "price": 199.99, "currency": "usd", "duration_days": 365},
}

class CheckoutRequest(BaseModel):
    plan: str
    origin_url: str

@app.post("/api/payments/checkout")
async def create_checkout(req: CheckoutRequest, request: Request, user=Depends(get_current_user)):
    if req.plan not in SUBSCRIPTION_PLANS or req.plan == "trial":
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    plan = SUBSCRIPTION_PLANS[req.plan]
    
    success_url = f"{req.origin_url}/subscription/success?session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{req.origin_url}/pages/pricing"
    
    # Create Stripe checkout session
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            "price_data": {
                "currency": plan["currency"],
                "product_data": {
                    "name": f"PumpRadar {req.plan.title()} Plan",
                    "description": f"Access to PumpRadar signals for {plan['duration_days']} days",
                },
                "unit_amount": int(plan["price"] * 100),  # Stripe uses cents
            },
            "quantity": 1,
        }],
        mode="payment",
        success_url=success_url,
        cancel_url=cancel_url,
        customer_email=user["email"],
        metadata={
            "user_id": str(user["_id"]),
            "user_email": user["email"],
            "plan": req.plan,
        }
    )
    
    # Store pending transaction
    await db.payment_transactions.insert_one({
        "session_id": session.id,
        "user_id": str(user["_id"]),
        "user_email": user["email"],
        "plan": req.plan,
        "amount": plan["price"],
        "currency": plan["currency"],
        "payment_status": "pending",
        "status": "initiated",
        "created_at": datetime.now(timezone.utc),
    })
    
    return api_ok({"url": session.url, "session_id": session.id})

@app.get("/api/payments/status/{session_id}")
async def check_payment_status(session_id: str, user=Depends(get_current_user)):
    # Get Stripe session status
    session = stripe.checkout.Session.retrieve(session_id)
    
    payment_status = "pending"
    if session.payment_status == "paid":
        payment_status = "paid"
    elif session.status == "expired":
        payment_status = "expired"
    
    # Update transaction if paid
    tx = await db.payment_transactions.find_one({"session_id": session_id})
    
    if payment_status == "paid" and tx and tx.get("payment_status") != "paid":
        plan_name = tx.get("plan", "monthly")
        plan = SUBSCRIPTION_PLANS.get(plan_name, SUBSCRIPTION_PLANS["monthly"])
        expiry = datetime.now(timezone.utc) + timedelta(days=plan["duration_days"])
        
        # Update user subscription
        await db.users.update_one(
            {"_id": ObjectId(tx["user_id"])},
            {"$set": {"subscription": plan_name, "subscription_expiry": expiry}}
        )
        
        # Update transaction
        await db.payment_transactions.update_one(
            {"session_id": session_id},
            {"$set": {"payment_status": "paid", "status": "completed", "completed_at": datetime.now(timezone.utc)}}
        )
    
    return api_ok({
        "status": session.status,
        "payment_status": payment_status,
        "session_id": session_id,
    })

@app.post("/api/webhook/stripe")
async def stripe_webhook(request: Request):
    body = await request.body()
    sig = request.headers.get("Stripe-Signature", "")
    endpoint_secret = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
    
    try:
        # Verify webhook signature if secret is configured
        if endpoint_secret:
            event = stripe.Webhook.construct_event(body, sig, endpoint_secret)
        else:
            # Without secret, just parse the event
            import json as json_lib
            event = json_lib.loads(body)
        
        event_type = event.get("type") if isinstance(event, dict) else event.type
        
        if event_type == "checkout.session.completed":
            session = event.get("data", {}).get("object", {}) if isinstance(event, dict) else event.data.object
            session_id = session.get("id") if isinstance(session, dict) else session.id
            payment_status = session.get("payment_status") if isinstance(session, dict) else session.payment_status
            
            if payment_status == "paid":
                tx = await db.payment_transactions.find_one({"session_id": session_id})
                if tx and tx.get("payment_status") != "paid":
                    plan_name = tx.get("plan", "monthly")
                    plan = SUBSCRIPTION_PLANS.get(plan_name, SUBSCRIPTION_PLANS["monthly"])
                    expiry = datetime.now(timezone.utc) + timedelta(days=plan["duration_days"])
                    
                    await db.users.update_one(
                        {"_id": ObjectId(tx["user_id"])},
                        {"$set": {"subscription": plan_name, "subscription_expiry": expiry}}
                    )
                    await db.payment_transactions.update_one(
                        {"session_id": session_id},
                        {"$set": {"payment_status": "paid", "status": "completed"}}
                    )
    except Exception as e:
        logger.error(f"Webhook error: {e}")
    
    return {"status": "ok"}

@app.get("/api/user/subscription")
async def get_subscription(user=Depends(get_current_user)):
    sub = user.get("subscription", "free")
    expiry = user.get("subscription_expiry")
    
    # Normalize expiry to timezone-aware datetime
    if expiry:
        if isinstance(expiry, str):
            expiry = datetime.fromisoformat(expiry.replace("Z", "+00:00"))
        if isinstance(expiry, datetime) and expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
    
    is_active = False
    if sub in ("monthly", "annual"):
        if expiry:
            is_active = datetime.now(timezone.utc) < expiry
        else:
            is_active = True
    elif sub == "trial":
        if expiry:
            is_active = datetime.now(timezone.utc) < expiry
    
    return api_ok({
        "subscription": sub,
        "is_active": is_active,
        "expiry": expiry.isoformat() if isinstance(expiry, datetime) else expiry,
        "plans": SUBSCRIPTION_PLANS,
    })

# ─────────────────────────────────────────────
# SCHEDULER
# ─────────────────────────────────────────────
from apscheduler.schedulers.asyncio import AsyncIOScheduler

scheduler = AsyncIOScheduler(timezone="UTC")

@app.on_event("startup")
async def startup_event():
    # Create indexes
    await db.users.create_index("email", unique=True)
    await db.signal_snapshots.create_index("timestamp")
    await db.payment_transactions.create_index("session_id", unique=True)
    
    # Start scheduler - hourly job for signals
    scheduler.add_job(fetch_and_store_signals, 'interval', hours=1, id='crypto_signals', replace_existing=True)
    
    # Accuracy tracking - runs hourly, 30 min offset
    scheduler.add_job(track_signal_accuracy, 'interval', hours=1, id='accuracy_tracker', replace_existing=True)
    
    # Market open emails (PRO feature)
    # London Stock Exchange opens at 08:00 UTC
    scheduler.add_job(send_london_market_email, 'cron', hour=8, minute=0, id='london_market_email', replace_existing=True)
    
    # New York Stock Exchange opens at 14:30 UTC (9:30 AM EST)
    scheduler.add_job(send_nyse_market_email, 'cron', hour=14, minute=30, id='nyse_market_email', replace_existing=True)
    
    scheduler.start()
    
    # Initial fetch with delay to avoid rate limiting on hot-reload
    async def delayed_fetch():
        await asyncio.sleep(30)  # Wait 30s before first fetch
        await fetch_and_store_signals()
    
    asyncio.create_task(delayed_fetch())
    logger.info("PumpRadar backend started - scheduler running hourly, first fetch in 30s")

@app.on_event("shutdown")
async def shutdown_event():
    scheduler.shutdown()
    client.close()

# ─────────────────────────────────────────────
# AI CHAT CUSTOMER SERVICE
# ─────────────────────────────────────────────
class ChatRequest(BaseModel):
    message: str
    history: Optional[List[dict]] = []

@app.post("/api/ai/chat")
async def ai_chat(req: ChatRequest, user=Depends(get_optional_user)):
    """AI customer service chat powered by Gemini - Smart & Helpful"""
    try:
        # Get latest signal context with details
        snapshot = await db.signal_snapshots.find_one({}, sort=[("timestamp", -1)])
        pump_signals = snapshot.get("pump_signals", []) if snapshot else []
        dump_signals = snapshot.get("dump_signals", []) if snapshot else []
        pump_count = len(pump_signals)
        dump_count = len(dump_signals)
        summary = snapshot.get("market_summary", "") if snapshot else ""
        fear_greed = snapshot.get("fear_greed", {}) if snapshot else {}
        trending = snapshot.get("trending", []) if snapshot else []
        
        # Build detailed signal context
        top_pumps = ", ".join([f"{s.get('symbol')} ({s.get('signal_strength', 0)}%)" for s in pump_signals[:5]]) or "None"
        top_dumps = ", ".join([f"{s.get('symbol')} ({s.get('signal_strength', 0)}%)" for s in dump_signals[:3]]) or "None"
        
        user_sub = "Free Trial"
        user_name = "Guest"
        if user:
            sub = user.get("subscription", "trial")
            user_sub = "Pro Monthly" if sub == "monthly" else "Pro Annual" if sub == "annual" else "Free Trial"
            user_name = user.get("name", "User")
        
        system_instruction = f"""You are PumpRadar AI - an intelligent crypto market assistant. You're knowledgeable, helpful, and precise.

PLATFORM OVERVIEW:
PumpRadar uses quantitative analysis + AI (Gemini) to detect cryptocurrency pump and dump signals. Data sources: CoinGecko (price/volume), Fear & Greed Index, social trending.

CURRENT LIVE DATA:
- Active PUMP signals: {pump_count} coins showing bullish momentum
- Active DUMP signals: {dump_count} coins showing bearish pressure
- Top PUMP candidates: {top_pumps}
- Top DUMP warnings: {top_dumps}
- Fear & Greed Index: {fear_greed.get('value', 'N/A')}/100 ({fear_greed.get('classification', 'N/A')})
- Trending on CoinGecko: {', '.join(trending[:5]) if trending else 'N/A'}
- Market Summary: {summary}

USER CONTEXT:
- Name: {user_name}
- Subscription: {user_sub}
- Access level: {'Full signal access' if user_sub != 'Free Trial' else 'Limited preview (upgrade for full access)'}

SUBSCRIPTION PLANS:
- Free Trial: 24 hours of full access (automatically granted on signup)
- Pro Monthly: $29.99/month - unlimited signals, AI analysis, coin details
- Pro Annual: $199.99/year (save $160!) - all Pro features

YOUR CAPABILITIES:
1. Explain current market signals with specific data
2. Describe how our quantitative scoring algorithm works (volume/mcap ratio, momentum divergence, trend alignment)
3. Help users understand pump/dump mechanics
4. Guide users through platform features
5. Answer general crypto questions
6. Explain subscription benefits

RESPONSE GUIDELINES:
- ALWAYS respond in English only
- Be concise but informative (2-4 sentences for simple questions, more for complex ones)
- Use specific numbers from live data when relevant
- When discussing signals, mention the actual coins and their scores
- For price predictions: explain we provide probability-based signals, not guarantees
- Always include: "This is not financial advice. Always do your own research."
- Be friendly and professional

If asked about a specific coin, check if it's in our current signals and provide details."""
        
        chat = genai.GenerativeModel(
            model_name="gemini-2.0-flash",
            system_instruction=system_instruction
        )
        
        response = await asyncio.to_thread(lambda: chat.generate_content(req.message).text)
        return api_ok({"reply": response})
    except Exception as e:
        logger.error(f"AI chat error: {e}")
        return api_ok({"reply": "I apologize, but I'm experiencing technical difficulties. Please try again in a moment. If the issue persists, our system may be updating - check back in a few minutes."})

# ─────────────────────────────────────────────
# COIN DETAIL
# ─────────────────────────────────────────────
def get_coin_chart_data(coin_id: str, days: int = 1) -> List[dict]:
    """Get hourly price + volume data from CoinGecko"""
    try:
        url = f"https://api.coingecko.com/api/v3/coins/{coin_id}/market_chart"
        params = {"vs_currency": "usd", "days": days, "interval": "hourly"}
        r = requests.get(url, params=params, headers=CG_HEADERS, timeout=15)
        if r.status_code != 200:
            return []
        data = r.json()
        prices = data.get("prices", [])
        volumes = data.get("total_volumes", [])
        result = []
        for i, (ts, price) in enumerate(prices[-24:]):
            vol = volumes[i][1] if i < len(volumes) else 0
            dt = datetime.fromtimestamp(ts / 1000, tz=timezone.utc)
            result.append({
                "time": dt.strftime("%H:%M"),
                "price": round(price, 6),
                "volume": round(vol),
                "open": round(price * 0.998, 6),
                "high": round(price * 1.005, 6),
                "low": round(price * 0.994, 6),
                "close": round(price, 6),
            })
        return result
    except Exception as e:
        logger.error(f"Chart data error: {e}")
        return []

def get_coin_exchanges(symbol: str, coin_id: str) -> List[dict]:
    """Build exchange list for a coin"""
    sym_lower = symbol.lower()
    cex_list = [
        {"name": "Binance", "url": f"https://www.binance.com/trade/{symbol}_USDT", "type": "cex"},
        {"name": "Coinbase", "url": f"https://www.coinbase.com/price/{coin_id}", "type": "cex"},
        {"name": "Kraken", "url": f"https://www.kraken.com/prices/{sym_lower}", "type": "cex"},
        {"name": "KuCoin", "url": f"https://www.kucoin.com/trade/{symbol}-USDT", "type": "cex"},
        {"name": "OKX", "url": f"https://www.okx.com/trade-spot/{sym_lower}-usdt", "type": "cex"},
        {"name": "Bybit", "url": f"https://www.bybit.com/trade/usdt/{symbol}USDT", "type": "cex"},
    ]
    dex_list = [
        {"name": "Uniswap", "url": f"https://app.uniswap.org/swap?outputCurrency={symbol}", "type": "dex"},
        {"name": "PancakeSwap", "url": f"https://pancakeswap.finance/swap?outputCurrency={symbol}", "type": "dex"},
        {"name": "dYdX", "url": f"https://dydx.trade/trade/{symbol}-USD", "type": "dex"},
    ]
    # Return top 4 CEX + 2 DEX
    return cex_list[:4] + dex_list[:2]

@app.get("/api/crypto/coin/{symbol}")
async def get_coin_detail(symbol: str, type: str = "pump", user=Depends(get_optional_user)):
    """Get detailed coin data with AI analysis"""
    symbol = symbol.upper()
    
    # Find signal in latest snapshot
    snapshot = await db.signal_snapshots.find_one({}, sort=[("timestamp", -1)])
    signal = None
    if snapshot:
        all_signals = snapshot.get("pump_signals", []) + snapshot.get("dump_signals", [])
        for s in all_signals:
            if s.get("symbol", "").upper() == symbol:
                signal = s
                break
    
    # Get CoinGecko market data
    try:
        url = "https://api.coingecko.com/api/v3/coins/markets"
        params = {"vs_currency": "usd", "ids": "", "symbols": symbol.lower(), "price_change_percentage": "1h,24h,7d"}
        # Search by symbol
        search_url = f"https://api.coingecko.com/api/v3/search?query={symbol}"
        sr = requests.get(search_url, headers=CG_HEADERS, timeout=10)
        coin_id = symbol.lower()
        if sr.status_code == 200:
            coins = sr.json().get("coins", [])
            for c in coins:
                if c.get("symbol", "").upper() == symbol:
                    coin_id = c.get("id", symbol.lower())
                    break
        
        market_url = f"https://api.coingecko.com/api/v3/coins/markets"
        mr = requests.get(market_url, params={
            "vs_currency": "usd", "ids": coin_id,
            "price_change_percentage": "1h,24h,7d"
        }, headers=CG_HEADERS, timeout=15)
        
        market_data = {}
        if mr.status_code == 200 and mr.json():
            market_data = mr.json()[0]
    except Exception as e:
        logger.error(f"CoinGecko detail error: {e}")
        market_data = {}
    
    price = market_data.get("current_price") or (signal.get("price") if signal else 0) or 0
    price_change_1h = market_data.get("price_change_percentage_1h_in_currency") or (signal.get("price_change_1h") if signal else 0) or 0
    price_change_24h = market_data.get("price_change_percentage_24h") or (signal.get("price_change_24h") if signal else 0) or 0
    price_change_7d = market_data.get("price_change_percentage_7d_in_currency") or 0
    volume_24h = market_data.get("total_volume") or (signal.get("volume_24h") if signal else 0) or 0
    market_cap = market_data.get("market_cap") or 0
    image = market_data.get("image") or (signal.get("image") if signal else "")
    coin_id = market_data.get("id") or symbol.lower()
    
    # VALIDATION: If no valid data found, return 404
    if price <= 0 and not signal:
        raise HTTPException(
            status_code=404, 
            detail=api_err(f"Coin '{symbol}' not found or has no valid market data. It may be delisted or not supported.", "COIN_NOT_FOUND")
        )
    
    # If coin has invalid data (price 0, market cap < $100k), warn user
    is_invalid_coin = price <= 0 or market_cap < 100000
    
    # Get chart data
    chart_data = get_coin_chart_data(coin_id, days=1)
    
    # AI detailed analysis
    ai_analysis = ""
    trend_conclusion = ""
    if signal:
        try:
            chat = genai.GenerativeModel(
                model_name="gemini-2.0-flash",
                system_instruction="You are a crypto technical analysis expert. You respond in English, concisely and directly."
            )
            
            prompt = f"""Analyze {symbol} ({signal.get('name', symbol)}) in detail as a {'PUMP' if type == 'pump' else 'DUMP'} signal.

Data:
- Price: ${price}
- 1h change: {price_change_1h}%
- 24h change: {price_change_24h}%
- 7d change: {price_change_7d}%
- 24h volume: ${volume_24h:,.0f}
- Market cap: ${market_cap:,.0f}
- AI signal strength: {signal.get('signal_strength', 0)}%
- Initial reason: {signal.get('reason', '')}

Respond with JSON (all text in English):
{{
  "analysis": "Detailed analysis in 3-4 sentences with specific technical reasons",
  "trend": "Clear conclusion about the trend and reasoning in 2 sentences, with key indicators"
}}"""
            
            resp = await asyncio.to_thread(lambda: chat.generate_content(prompt).text)
            import json as json_lib
            resp_clean = resp.strip()
            if resp_clean.startswith("```"):
                resp_clean = "\n".join([l for l in resp_clean.split("\n") if not l.startswith("```")])
            detail_json = json_lib.loads(resp_clean)
            ai_analysis = detail_json.get("analysis", signal.get("reason", ""))
            trend_conclusion = detail_json.get("trend", "")
        except Exception as e:
            logger.error(f"Coin detail AI error: {e}")
            ai_analysis = signal.get("reason", "Data indicates a significant signal.")
            trend_conclusion = f"{'Positive' if type == 'pump' else 'Negative'} trend based on volume and price movement."
    else:
        ai_analysis = f"No active signal for {symbol} in the last hour of analysis."
        trend_conclusion = "Monitor the market for future signals."
    
    exchanges = get_coin_exchanges(symbol, coin_id)
    
    return api_ok({
        "symbol": symbol,
        "name": market_data.get("name") or (signal.get("name") if signal else symbol),
        "image": image,
        "price": price,
        "price_change_1h": price_change_1h,
        "price_change_24h": price_change_24h,
        "price_change_7d": price_change_7d,
        "volume_24h": volume_24h,
        "market_cap": market_cap,
        "signal_type": type,
        "signal_strength": signal.get("signal_strength", 0) if signal else 0,
        "reason": signal.get("reason", "") if signal else "",
        "confidence": signal.get("confidence", "medium") if signal else "medium",
        "risk_level": signal.get("risk_level", "medium") if signal else "medium",
        "ai_analysis": ai_analysis,
        "trend_conclusion": trend_conclusion,
        "exchanges": exchanges,
        "chart_data": chart_data,
    })

# ─────────────────────────────────────────────
# ADMIN ENDPOINTS
# ─────────────────────────────────────────────
async def require_admin(user=Depends(get_current_user)):
    if "admin" not in user.get("roles", []):
        raise HTTPException(status_code=403, detail=api_err("Admin access required", "FORBIDDEN"))
    return user

@app.get("/api/admin/users")
async def admin_list_users(skip: int = 0, limit: int = 100, admin=Depends(require_admin)):
    users = await db.users.find({}).skip(skip).limit(limit).to_list(length=limit)
    return api_ok({"users": [doc_to_user(u) for u in users], "total": await db.users.count_documents({})})

@app.delete("/api/admin/users/{user_id}")
async def admin_delete_user(user_id: str, admin=Depends(require_admin)):
    result = await db.users.delete_one({"_id": ObjectId(user_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail=api_err("User not found", "NOT_FOUND"))
    return api_ok({"message": "User deleted"})

@app.patch("/api/admin/users/{user_id}")
async def admin_update_user(user_id: str, body: dict, admin=Depends(require_admin)):
    update = {}
    if "subscription" in body:
        update["subscription"] = body["subscription"]
        
        # Handle duration parameter for free subscriptions
        duration = body.get("duration")
        if duration == "month":
            update["subscription_expiry"] = datetime.now(timezone.utc) + timedelta(days=30)
        elif duration == "year":
            update["subscription_expiry"] = datetime.now(timezone.utc) + timedelta(days=365)
        else:
            # Use default from SUBSCRIPTION_PLANS
            plan = SUBSCRIPTION_PLANS.get(body["subscription"])
            if plan:
                update["subscription_expiry"] = datetime.now(timezone.utc) + timedelta(days=plan["duration_days"])
    
    if "roles" in body:
        update["roles"] = body["roles"]
    if "name" in body:
        update["name"] = body["name"]
    if not update:
        raise HTTPException(status_code=400, detail="Nothing to update")
    await db.users.update_one({"_id": ObjectId(user_id)}, {"$set": update})
    user = await db.users.find_one({"_id": ObjectId(user_id)})
    return api_ok({"user": doc_to_user(user)})

@app.post("/api/admin/make-admin/{user_id}")
async def make_admin(user_id: str, admin=Depends(require_admin)):
    await db.users.update_one({"_id": ObjectId(user_id)}, {"$addToSet": {"roles": "admin"}})
    return api_ok({"message": "User promoted to admin"})

@app.post("/api/admin/run-signal-job")
async def run_signal_job(admin=Depends(require_admin)):
    """Force run the signal analysis job (admin only)"""
    try:
        await fetch_and_store_signals()
        return api_ok({"message": "Signal job completed successfully"})
    except Exception as e:
        logger.error(f"Manual signal job failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ─────────────────────────────────────────────
# HOME MODULE STUBS (required by Katalyst template)
# ─────────────────────────────────────────────
@app.get("/api/home/dashboard")
async def home_dashboard(user=Depends(get_current_user)):
    """Home dashboard data for Katalyst home module"""
    u = doc_to_user(user)
    return api_ok({
        "user": {"name": u.get("name", "User"), "email": u["email"], "avatarUrl": None},
        "workspace": {"name": "PumpRadar", "environment": "production"},
        "stats": {"pumpSignals": 0, "dumpSignals": 0, "users": 1},
        "checklist": [],
        "recentActivity": [],
        "apps": [],
        "tourCompleted": True,
    })

@app.patch("/api/home/checklist/{item_id}")
async def update_checklist(item_id: str, user=Depends(get_current_user)):
    return api_ok({"message": "OK"})

@app.get("/api/home/tour")
async def get_tour(user=Depends(get_current_user)):
    return api_ok({"completed": True, "skipped": True})

@app.post("/api/home/tour/{action}")
async def tour_action(action: str, user=Depends(get_current_user)):
    return api_ok({"completed": True, "skipped": True})

# ─────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────
@app.get("/api/health")
async def health():
    return {"status": "ok", "app": "PumpRadar", "version": "1.0.0"}
